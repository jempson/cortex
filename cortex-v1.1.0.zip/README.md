# CORTEX - Secure Communications System

A Wave-inspired, Firefly-themed communication platform with real-time collaboration, threaded conversations, and playback features.

## Features

- **User Authentication**: Register, login, secure JWT-based sessions
- **Threaded Conversations**: Nested replies with collapsible threads
- **Privacy Levels**: Private, Group, Cross-Server, and Public message types
- **Public Threads**: Visible to all users, auto-join when posting
- **Playback Mode**: Replay conversations chronologically like Google Wave
- **Real-time Updates**: WebSocket-based live message delivery
- **Contacts Management**: Search users and manage your contact list

## Security Features (v1.1.0)

- **Rate Limiting**: 
  - Login: 5 attempts per 15 minutes per user/IP
  - Registration: 3 accounts per hour per IP
  - API: 100 requests per minute
- **Account Lockout**: 15-minute lockout after 5 failed login attempts
- **Input Sanitization**: XSS protection on all user input
- **Password Requirements**: Min 8 chars, uppercase, lowercase, number
- **Security Headers**: Helmet.js middleware
- **CORS Protection**: Configurable allowed origins

## Quick Start (Development)

### 1. Start the Server

```bash
cd server
npm install
npm start
```

### 2. Start the Client

```bash
cd client
npm install
npm run dev
```

### 3. Create Your Account

Navigate to http://localhost:3000 and register a new account.

**For development with demo data**, start the server with:
```bash
SEED_DEMO_DATA=true npm start
```
This creates demo users (mal, zoe, etc.) with password `Demo123!`

## Production Deployment

### Environment Configuration

Copy `.env.example` to `.env` and configure:

```bash
cd server
cp .env.example .env
```

**Required for production:**

```env
# Generate a secure secret:
# node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
JWT_SECRET=your-64-byte-hex-secret

# Restrict CORS to your domain
ALLOWED_ORIGINS=https://cortex.yourdomain.com
```

### Nginx Reverse Proxy

Example nginx configuration:

```nginx
server {
    listen 443 ssl http2;
    server_name cortex.yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/cortex.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/cortex.yourdomain.com/privkey.pem;

    # API and WebSocket
    location /api {
        proxy_pass http://127.0.0.1:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /ws {
        proxy_pass http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # Static frontend (after building)
    location / {
        root /var/www/cortex;
        try_files $uri $uri/ /index.html;
    }
}
```

### Build Frontend for Production

```bash
cd client
npm run build
# Deploy dist/ folder to your web server
```

### Update Client API URLs

Before building, update `CortexApp.jsx`:

```javascript
const API_URL = 'https://cortex.yourdomain.com/api';
const WS_URL = 'wss://cortex.yourdomain.com';
```

### Running with PM2

```bash
npm install -g pm2
cd server
pm2 start server.js --name cortex
pm2 save
pm2 startup
```

## API Endpoints

### Authentication
| Method | Endpoint | Description | Rate Limit |
|--------|----------|-------------|------------|
| POST | `/api/auth/register` | Create account | 3/hour |
| POST | `/api/auth/login` | Login | 5/15min |
| GET | `/api/auth/me` | Get current user | - |
| POST | `/api/auth/logout` | Logout | - |

### Threads
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/threads` | List user's threads (includes public) |
| GET | `/api/threads/:id` | Get thread with messages |
| POST | `/api/threads` | Create new thread |

### Messages
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/messages` | Send a message (auto-joins public threads) |
| PUT | `/api/messages/:id` | Edit a message |

### Users
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/users/search?q=` | Search users by name/username |

### Contacts
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/contacts` | List contacts |
| POST | `/api/contacts` | Add a contact by username |
| DELETE | `/api/contacts/:id` | Remove a contact |

### Health
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Server status |

## Architecture

```
cortex/
├── server/
│   ├── server.js          # Express + WebSocket server
│   ├── cortex-data.json   # Data persistence (auto-created)
│   ├── .env.example       # Environment template
│   └── package.json
├── client/
│   ├── CortexApp.jsx      # Main React application
│   ├── main.jsx           # Entry point
│   ├── index.html         # HTML template
│   ├── vite.config.js     # Vite configuration
│   └── package.json
└── README.md
```

## Security Considerations

### What's Protected
- ✅ Brute force login attacks (rate limiting + lockout)
- ✅ XSS attacks (input sanitization)
- ✅ Weak passwords (strength requirements)
- ✅ Common security headers (Helmet)
- ✅ CORS (configurable)

### What's NOT Protected (Yet)
- ❌ End-to-end encryption (messages readable by server)
- ❌ CSRF tokens (relies on JWT in Authorization header)
- ❌ SQL injection (N/A - uses JSON file storage)

### Recommendations for Production
1. Always use HTTPS (TLS termination at nginx)
2. Set a strong, unique `JWT_SECRET`
3. Configure `ALLOWED_ORIGINS` for your domain
4. Consider adding fail2ban for additional IP blocking
5. Back up `cortex-data.json` regularly
6. Monitor logs for suspicious activity

## Future Security Roadmap

1. **End-to-End Encryption**: Client-side encryption using libsodium
2. **Two-Factor Authentication**: TOTP support
3. **Audit Logging**: Track security events
4. **Session Management**: View/revoke active sessions

## License

MIT
