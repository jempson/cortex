import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import sanitizeHtml from 'sanitize-html';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ============ Configuration ============
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || (() => {
  console.warn('⚠️  WARNING: Using default JWT_SECRET. Set JWT_SECRET environment variable in production!');
  return 'cortex-default-secret-CHANGE-ME';
})();
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';
const DATA_FILE = path.join(__dirname, 'cortex-data.json');

// CORS configuration - set ALLOWED_ORIGINS env var for production
// Example: ALLOWED_ORIGINS=https://cortex.yourdomain.com,https://www.yourdomain.com
const ALLOWED_ORIGINS = process.env.ALLOWED_ORIGINS 
  ? process.env.ALLOWED_ORIGINS.split(',').map(s => s.trim())
  : null; // null = allow all (development mode)

// ============ Security: Rate Limiting ============
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts per window
  message: { error: 'Too many login attempts. Please try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip + ':' + (req.body?.username || 'unknown'),
});

const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // 3 registrations per hour per IP
  message: { error: 'Too many registration attempts. Please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute
  message: { error: 'Too many requests. Please slow down.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// ============ Security: Account Lockout Tracking ============
const failedAttempts = new Map(); // username -> { count, lockedUntil }
const LOCKOUT_THRESHOLD = 5;
const LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes

function checkAccountLockout(username) {
  const record = failedAttempts.get(username);
  if (!record) return { locked: false };
  
  if (record.lockedUntil && Date.now() < record.lockedUntil) {
    const remainingMs = record.lockedUntil - Date.now();
    const remainingMin = Math.ceil(remainingMs / 60000);
    return { locked: true, remainingMin };
  }
  
  // Lockout expired, reset
  if (record.lockedUntil && Date.now() >= record.lockedUntil) {
    failedAttempts.delete(username);
  }
  
  return { locked: false };
}

function recordFailedAttempt(username) {
  const record = failedAttempts.get(username) || { count: 0, lockedUntil: null };
  record.count += 1;
  
  if (record.count >= LOCKOUT_THRESHOLD) {
    record.lockedUntil = Date.now() + LOCKOUT_DURATION;
    console.log(`🔒 Account locked: ${username} until ${new Date(record.lockedUntil).toISOString()}`);
  }
  
  failedAttempts.set(username, record);
}

function clearFailedAttempts(username) {
  failedAttempts.delete(username);
}

// ============ Security: Input Sanitization ============
const sanitizeOptions = {
  allowedTags: [], // Strip ALL HTML tags
  allowedAttributes: {},
  textFilter: (text) => text, // Keep plain text
};

function sanitizeInput(input) {
  if (typeof input !== 'string') return input;
  return sanitizeHtml(input, sanitizeOptions).trim();
}

function sanitizeMessage(content) {
  if (typeof content !== 'string') return '';
  // Remove HTML but preserve some formatting via escaping
  return sanitizeHtml(content, sanitizeOptions)
    .trim()
    .slice(0, 10000); // Max message length
}

// ============ Security: Password Validation ============
function validatePassword(password) {
  const errors = [];
  
  // Handle null/undefined
  if (!password || typeof password !== 'string') {
    return ['Password is required'];
  }
  
  if (password.length < 8) {
    errors.push('Password must be at least 8 characters');
  }
  if (password.length > 128) {
    errors.push('Password must be less than 128 characters');
  }
  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain a lowercase letter');
  }
  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain an uppercase letter');
  }
  if (!/[0-9]/.test(password)) {
    errors.push('Password must contain a number');
  }
  
  return errors;
}

// ============ In-Memory Database with JSON Persistence ============
class Database {
  constructor() {
    this.data = {
      users: [],
      threads: [],
      threadParticipants: [],
      messages: [],
      messageHistory: [],
      contacts: [],
    };
    this.load();
  }

  load() {
    try {
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        this.data = JSON.parse(raw);
        console.log('📂 Loaded existing data');
      } else {
        // Check if demo data should be seeded
        if (process.env.SEED_DEMO_DATA === 'true') {
          this.seedDemoData();
        } else {
          this.initEmpty();
        }
      }
    } catch (err) {
      console.error('Failed to load data:', err);
      this.initEmpty();
    }
  }

  save() {
    try {
      fs.writeFileSync(DATA_FILE, JSON.stringify(this.data, null, 2));
    } catch (err) {
      console.error('Failed to save data:', err);
    }
  }

  initEmpty() {
    console.log('📝 Initializing empty database');
    // Data is already empty from constructor
    this.save();
    console.log('✅ Database initialized - ready for new users');
  }

  seedDemoData() {
    console.log('🌱 Seeding demo data...');
    // Demo password: Demo123! (meets requirements)
    const passwordHash = bcrypt.hashSync('Demo123!', 12);
    const now = new Date().toISOString();

    const demoUsers = [
      { id: 'user-mal', username: 'mal', email: 'mal@serenity.ship', displayName: 'Malcolm Reynolds', avatar: 'M', nodeName: 'Serenity', status: 'offline' },
      { id: 'user-zoe', username: 'zoe', email: 'zoe@serenity.ship', displayName: 'Zoe Washburne', avatar: 'Z', nodeName: 'Serenity', status: 'offline' },
      { id: 'user-wash', username: 'wash', email: 'wash@serenity.ship', displayName: 'Hoban Washburne', avatar: 'W', nodeName: 'Serenity', status: 'offline' },
      { id: 'user-kaylee', username: 'kaylee', email: 'kaylee@serenity.ship', displayName: 'Kaylee Frye', avatar: 'K', nodeName: 'Serenity', status: 'offline' },
      { id: 'user-jayne', username: 'jayne', email: 'jayne@serenity.ship', displayName: 'Jayne Cobb', avatar: 'J', nodeName: 'Serenity', status: 'offline' },
      { id: 'user-inara', username: 'inara', email: 'inara@companion.guild', displayName: 'Inara Serra', avatar: 'I', nodeName: 'Guild', status: 'offline' },
      { id: 'user-simon', username: 'simon', email: 'simon@serenity.ship', displayName: 'Simon Tam', avatar: 'S', nodeName: 'Serenity', status: 'offline' },
      { id: 'user-river', username: 'river', email: 'river@serenity.ship', displayName: 'River Tam', avatar: 'R', nodeName: 'Serenity', status: 'offline' },
    ];

    this.data.users = demoUsers.map(u => ({
      ...u,
      passwordHash,
      createdAt: now,
      lastSeen: now,
    }));

    this.data.threads = [
      { id: 'thread-1', title: 'Persephone Job Planning', privacy: 'group', createdBy: 'user-mal', createdAt: now, updatedAt: now },
      { id: 'thread-2', title: 'Engine Repairs Discussion', privacy: 'private', createdBy: 'user-kaylee', createdAt: now, updatedAt: now },
      { id: 'thread-3', title: 'Crew Meeting Notes', privacy: 'group', createdBy: 'user-mal', createdAt: now, updatedAt: now },
    ];

    this.data.threadParticipants = [
      { threadId: 'thread-1', userId: 'user-mal', joinedAt: now },
      { threadId: 'thread-1', userId: 'user-zoe', joinedAt: now },
      { threadId: 'thread-1', userId: 'user-jayne', joinedAt: now },
      { threadId: 'thread-2', userId: 'user-kaylee', joinedAt: now },
      { threadId: 'thread-2', userId: 'user-mal', joinedAt: now },
      { threadId: 'thread-3', userId: 'user-mal', joinedAt: now },
      { threadId: 'thread-3', userId: 'user-zoe', joinedAt: now },
      { threadId: 'thread-3', userId: 'user-wash', joinedAt: now },
      { threadId: 'thread-3', userId: 'user-kaylee', joinedAt: now },
      { threadId: 'thread-3', userId: 'user-jayne', joinedAt: now },
    ];

    this.data.messages = [
      { id: 'msg-1', threadId: 'thread-1', parentId: null, authorId: 'user-mal', content: 'Got a wave from Badger. Looks like he has work for us on Persephone.', privacy: 'group', version: 1, createdAt: now, editedAt: null },
      { id: 'msg-2', threadId: 'thread-1', parentId: 'msg-1', authorId: 'user-zoe', content: 'What kind of work? Last time we dealt with Badger things got complicated.', privacy: 'group', version: 1, createdAt: now, editedAt: null },
      { id: 'msg-3', threadId: 'thread-1', parentId: 'msg-2', authorId: 'user-mal', content: 'Cargo run. Claims it is legit this time. Meeting him tomorrow at the docks.', privacy: 'group', version: 1, createdAt: now, editedAt: null },
      { id: 'msg-4', threadId: 'thread-1', parentId: 'msg-1', authorId: 'user-jayne', content: 'If there is coin involved, I am in. How much we talking?', privacy: 'group', version: 1, createdAt: now, editedAt: null },
      { id: 'msg-5', threadId: 'thread-2', parentId: null, authorId: 'user-kaylee', content: 'Captain, the compression coil is acting up again. Need parts.', privacy: 'private', version: 1, createdAt: now, editedAt: null },
      { id: 'msg-6', threadId: 'thread-2', parentId: 'msg-5', authorId: 'user-mal', content: 'Can you keep her flying until we reach Persephone?', privacy: 'private', version: 1, createdAt: now, editedAt: null },
      { id: 'msg-7', threadId: 'thread-2', parentId: 'msg-6', authorId: 'user-kaylee', content: 'I will do my best, but we need that part soon or we will be dead in the water.', privacy: 'private', version: 1, createdAt: now, editedAt: null },
    ];

    this.data.contacts = [
      { userId: 'user-mal', contactId: 'user-zoe', addedAt: now },
      { userId: 'user-mal', contactId: 'user-wash', addedAt: now },
      { userId: 'user-mal', contactId: 'user-kaylee', addedAt: now },
      { userId: 'user-mal', contactId: 'user-jayne', addedAt: now },
      { userId: 'user-mal', contactId: 'user-inara', addedAt: now },
      { userId: 'user-mal', contactId: 'user-simon', addedAt: now },
      { userId: 'user-mal', contactId: 'user-river', addedAt: now },
    ];

    this.save();
    console.log('✅ Demo data seeded (password: Demo123!)');
  }

  // User methods
  findUserByUsername(username) {
    const sanitized = sanitizeInput(username)?.toLowerCase();
    return this.data.users.find(u => 
      u.username.toLowerCase() === sanitized || 
      u.email.toLowerCase() === sanitized
    );
  }

  findUserById(id) {
    return this.data.users.find(u => u.id === id);
  }

  createUser(userData) {
    const user = { ...userData, createdAt: new Date().toISOString(), lastSeen: new Date().toISOString() };
    this.data.users.push(user);
    this.save();
    return user;
  }

  updateUserStatus(userId, status) {
    const user = this.findUserById(userId);
    if (user) {
      user.status = status;
      user.lastSeen = new Date().toISOString();
      this.save();
    }
  }

  // Thread methods
  getThreadsForUser(userId) {
    const participantThreadIds = this.data.threadParticipants
      .filter(p => p.userId === userId)
      .map(p => p.threadId);

    // Get threads where user is participant OR thread is public
    return this.data.threads
      .filter(t => participantThreadIds.includes(t.id) || t.privacy === 'public')
      .map(thread => {
        const creator = this.findUserById(thread.createdBy);
        const participants = this.getThreadParticipants(thread.id);
        const messageCount = this.data.messages.filter(m => m.threadId === thread.id).length;
        const isParticipant = participantThreadIds.includes(thread.id);

        return {
          ...thread,
          creator_name: creator?.displayName || 'Unknown',
          creator_avatar: creator?.avatar || '?',
          participants,
          message_count: messageCount,
          is_participant: isParticipant,
        };
      })
      .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
  }

  getThread(threadId) {
    return this.data.threads.find(t => t.id === threadId);
  }

  isThreadParticipant(threadId, userId) {
    // Check if user is a participant
    const isParticipant = this.data.threadParticipants.some(
      p => p.threadId === threadId && p.userId === userId
    );
    if (isParticipant) return true;
    
    // Allow access to public threads
    const thread = this.getThread(threadId);
    return thread?.privacy === 'public';
  }

  // Add user to thread as participant
  addThreadParticipant(threadId, userId) {
    const existing = this.data.threadParticipants.find(
      p => p.threadId === threadId && p.userId === userId
    );
    if (existing) return false;
    
    this.data.threadParticipants.push({
      threadId,
      userId,
      joinedAt: new Date().toISOString(),
    });
    this.save();
    return true;
  }

  // Search users by username or display name
  searchUsers(query, excludeUserId) {
    if (!query || query.length < 2) return [];
    const lowerQuery = query.toLowerCase();
    
    return this.data.users
      .filter(u => 
        u.id !== excludeUserId &&
        (u.username.toLowerCase().includes(lowerQuery) ||
         u.displayName.toLowerCase().includes(lowerQuery))
      )
      .slice(0, 10) // Limit results
      .map(u => ({
        id: u.id,
        username: u.username,
        displayName: u.displayName,
        avatar: u.avatar,
        status: u.status,
        nodeName: u.nodeName,
      }));
  }

  createThread(threadData) {
    const now = new Date().toISOString();
    const thread = {
      id: `thread-${uuidv4()}`,
      title: sanitizeInput(threadData.title).slice(0, 200),
      privacy: threadData.privacy,
      createdBy: threadData.createdBy,
      createdAt: now,
      updatedAt: now,
    };
    this.data.threads.push(thread);

    this.data.threadParticipants.push({
      threadId: thread.id,
      userId: threadData.createdBy,
      joinedAt: now,
    });

    if (threadData.participants) {
      for (const userId of threadData.participants) {
        if (userId !== threadData.createdBy) {
          this.data.threadParticipants.push({
            threadId: thread.id,
            userId,
            joinedAt: now,
          });
        }
      }
    }

    this.save();
    return thread;
  }

  updateThreadTimestamp(threadId) {
    const thread = this.getThread(threadId);
    if (thread) {
      thread.updatedAt = new Date().toISOString();
      this.save();
    }
  }

  getThreadParticipants(threadId) {
    return this.data.threadParticipants
      .filter(p => p.threadId === threadId)
      .map(p => {
        const user = this.findUserById(p.userId);
        return user ? {
          id: user.id,
          name: user.displayName,
          avatar: user.avatar,
          status: user.status,
        } : null;
      })
      .filter(Boolean);
  }

  // Message methods
  getMessagesForThread(threadId) {
    return this.data.messages
      .filter(m => m.threadId === threadId)
      .map(m => {
        const author = this.findUserById(m.authorId);
        return {
          ...m,
          sender_name: author?.displayName || 'Unknown',
          sender_avatar: author?.avatar || '?',
          sender_handle: author?.username || 'unknown',
          author_id: m.authorId,
          parent_id: m.parentId,
          thread_id: m.threadId,
          created_at: m.createdAt,
          edited_at: m.editedAt,
        };
      })
      .sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
  }

  createMessage(messageData) {
    const now = new Date().toISOString();
    const message = {
      id: `msg-${uuidv4()}`,
      threadId: messageData.threadId,
      parentId: messageData.parentId,
      authorId: messageData.authorId,
      content: sanitizeMessage(messageData.content),
      privacy: messageData.privacy,
      version: 1,
      createdAt: now,
      editedAt: null,
    };
    this.data.messages.push(message);
    this.updateThreadTimestamp(messageData.threadId);
    this.save();

    const author = this.findUserById(messageData.authorId);
    return {
      ...message,
      sender_name: author?.displayName || 'Unknown',
      sender_avatar: author?.avatar || '?',
      sender_handle: author?.username || 'unknown',
      author_id: message.authorId,
      parent_id: message.parentId,
      thread_id: message.threadId,
      created_at: message.createdAt,
      edited_at: message.editedAt,
    };
  }

  updateMessage(messageId, content) {
    const message = this.data.messages.find(m => m.id === messageId);
    if (!message) return null;

    this.data.messageHistory.push({
      id: `hist-${uuidv4()}`,
      messageId,
      content: message.content,
      version: message.version,
      editedAt: new Date().toISOString(),
    });

    message.content = sanitizeMessage(content);
    message.version += 1;
    message.editedAt = new Date().toISOString();
    this.save();

    const author = this.findUserById(message.authorId);
    return {
      ...message,
      sender_name: author?.displayName || 'Unknown',
      sender_avatar: author?.avatar || '?',
      sender_handle: author?.username || 'unknown',
      author_id: message.authorId,
      parent_id: message.parentId,
      thread_id: message.threadId,
      created_at: message.createdAt,
      edited_at: message.editedAt,
    };
  }

  // Contact methods
  getContactsForUser(userId) {
    return this.data.contacts
      .filter(c => c.userId === userId)
      .map(c => {
        const contact = this.findUserById(c.contactId);
        return contact ? {
          id: contact.id,
          username: contact.username,
          name: contact.displayName,
          avatar: contact.avatar,
          status: contact.status,
          nodeName: contact.nodeName,
        } : null;
      })
      .filter(Boolean);
  }

  addContact(userId, contactId) {
    const existing = this.data.contacts.find(c => c.userId === userId && c.contactId === contactId);
    if (existing) return false;

    this.data.contacts.push({
      userId,
      contactId,
      addedAt: new Date().toISOString(),
    });
    this.save();
    return true;
  }
}

const db = new Database();

// ============ Express App ============
const app = express();

// Security middleware
app.use(helmet({
  contentSecurityPolicy: false, // Disable for development, configure properly for production
  crossOriginEmbedderPolicy: false,
}));

// CORS configuration
app.use(cors({
  origin: ALLOWED_ORIGINS ? (origin, callback) => {
    if (!origin || ALLOWED_ORIGINS.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('CORS not allowed'));
    }
  } : true,
  credentials: true,
}));

app.use(express.json({ limit: '100kb' })); // Limit body size

// Apply general rate limiting to all API routes
app.use('/api/', apiLimiter);

// Trust proxy (important for rate limiting behind nginx)
app.set('trust proxy', 1);

// ============ Auth Middleware ============
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = decoded;
    next();
  });
}

// ============ Auth Routes ============
app.post('/api/auth/register', registerLimiter, async (req, res) => {
  try {
    const username = sanitizeInput(req.body.username);
    const email = sanitizeInput(req.body.email);
    const password = req.body.password; // Don't sanitize password
    const displayName = sanitizeInput(req.body.displayName);

    if (!username || !email || !password) {
      return res.status(400).json({ error: 'Username, email and password are required' });
    }

    // Validate username format
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
      return res.status(400).json({ 
        error: 'Username must be 3-20 characters and contain only letters, numbers, and underscores' 
      });
    }

    // Validate email format
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: 'Invalid email format' });
    }

    // Validate password strength
    const passwordErrors = validatePassword(password);
    if (passwordErrors.length > 0) {
      return res.status(400).json({ error: passwordErrors.join('. ') });
    }

    // Check if user exists
    const existing = db.findUserByUsername(username) || db.findUserByUsername(email);
    if (existing) {
      return res.status(409).json({ error: 'Username or email already exists' });
    }

    const id = `user-${uuidv4()}`;
    const passwordHash = await bcrypt.hash(password, 12); // Increased from 10 to 12 rounds
    const avatar = (displayName || username)[0].toUpperCase();

    const user = db.createUser({
      id,
      username: username.toLowerCase(),
      email: email.toLowerCase(),
      passwordHash,
      displayName: displayName || username,
      avatar,
      nodeName: 'Local',
      status: 'online',
    });

    const token = jwt.sign({ userId: id, username: user.username }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    console.log(`✅ New user registered: ${username}`);

    res.status(201).json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        displayName: user.displayName,
        avatar: user.avatar,
        nodeName: user.nodeName,
        status: user.status,
      },
    });
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

app.post('/api/auth/login', loginLimiter, async (req, res) => {
  try {
    const username = sanitizeInput(req.body.username);
    const password = req.body.password;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    // Check account lockout
    const lockout = checkAccountLockout(username);
    if (lockout.locked) {
      return res.status(429).json({ 
        error: `Account temporarily locked. Try again in ${lockout.remainingMin} minutes.` 
      });
    }

    const user = db.findUserByUsername(username);
    if (!user) {
      recordFailedAttempt(username);
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(password, user.passwordHash);
    if (!validPassword) {
      recordFailedAttempt(username);
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Success - clear failed attempts
    clearFailedAttempts(username);
    db.updateUserStatus(user.id, 'online');

    const token = jwt.sign({ userId: user.id, username: user.username }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    console.log(`✅ User logged in: ${username}`);

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        displayName: user.displayName,
        avatar: user.avatar,
        nodeName: user.nodeName,
        status: 'online',
      },
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed' });
  }
});

app.get('/api/auth/me', authenticateToken, (req, res) => {
  const user = db.findUserById(req.user.userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  res.json({
    id: user.id,
    username: user.username,
    email: user.email,
    displayName: user.displayName,
    avatar: user.avatar,
    nodeName: user.nodeName,
    status: user.status,
  });
});

app.post('/api/auth/logout', authenticateToken, (req, res) => {
  db.updateUserStatus(req.user.userId, 'offline');
  res.json({ success: true });
});

// ============ Thread Routes ============
app.get('/api/threads', authenticateToken, (req, res) => {
  const threads = db.getThreadsForUser(req.user.userId);
  res.json(threads);
});

app.get('/api/threads/:id', authenticateToken, (req, res) => {
  const threadId = sanitizeInput(req.params.id);
  const thread = db.getThread(threadId);
  
  if (!thread) {
    return res.status(404).json({ error: 'Thread not found' });
  }

  // Authorization check
  if (!db.isThreadParticipant(threadId, req.user.userId)) {
    return res.status(403).json({ error: 'Access denied' });
  }

  const creator = db.findUserById(thread.createdBy);
  const participants = db.getThreadParticipants(thread.id);
  const allMessages = db.getMessagesForThread(thread.id);

  function buildMessageTree(messages, parentId = null) {
    return messages
      .filter(m => m.parent_id === parentId)
      .map(m => ({
        ...m,
        children: buildMessageTree(messages, m.id),
      }));
  }

  const messages = buildMessageTree(allMessages);

  res.json({
    ...thread,
    creator_name: creator?.displayName || 'Unknown',
    participants,
    messages,
    all_messages: allMessages,
  });
});

app.post('/api/threads', authenticateToken, (req, res) => {
  const title = sanitizeInput(req.body.title);
  const privacy = ['private', 'group', 'crossServer', 'public'].includes(req.body.privacy) 
    ? req.body.privacy 
    : 'private';
  const participants = req.body.participants;

  if (!title || title.length < 1) {
    return res.status(400).json({ error: 'Title is required' });
  }

  if (title.length > 200) {
    return res.status(400).json({ error: 'Title must be less than 200 characters' });
  }

  const thread = db.createThread({
    title,
    privacy,
    createdBy: req.user.userId,
    participants,
  });

  const result = {
    ...thread,
    creator_name: db.findUserById(req.user.userId)?.displayName || 'Unknown',
    participants: db.getThreadParticipants(thread.id),
    message_count: 0,
  };

  broadcastToThread(thread.id, { type: 'thread_created', thread: result });

  res.status(201).json(result);
});

// ============ Message Routes ============
app.post('/api/messages', authenticateToken, (req, res) => {
  const threadId = sanitizeInput(req.body.thread_id);
  const parentId = req.body.parent_id ? sanitizeInput(req.body.parent_id) : null;
  const content = req.body.content;
  const privacy = req.body.privacy;

  if (!threadId || !content) {
    return res.status(400).json({ error: 'Thread ID and content are required' });
  }

  const thread = db.getThread(threadId);
  if (!thread) {
    return res.status(404).json({ error: 'Thread not found' });
  }

  // Check access - participants can always post, others only to public threads
  const isParticipant = db.data.threadParticipants.some(
    p => p.threadId === threadId && p.userId === req.user.userId
  );
  
  if (!isParticipant && thread.privacy !== 'public') {
    return res.status(403).json({ error: 'Access denied' });
  }

  // Auto-join public threads when posting
  if (!isParticipant && thread.privacy === 'public') {
    db.addThreadParticipant(threadId, req.user.userId);
  }

  if (content.length > 10000) {
    return res.status(400).json({ error: 'Message too long (max 10000 characters)' });
  }

  const message = db.createMessage({
    threadId,
    parentId,
    authorId: req.user.userId,
    content,
    privacy: privacy || thread.privacy,
  });

  broadcastToThread(threadId, { type: 'new_message', data: message });

  res.status(201).json(message);
});

app.put('/api/messages/:id', authenticateToken, (req, res) => {
  const messageId = sanitizeInput(req.params.id);
  const content = req.body.content;
  const message = db.data.messages.find(m => m.id === messageId);

  if (!message) {
    return res.status(404).json({ error: 'Message not found' });
  }

  if (message.authorId !== req.user.userId) {
    return res.status(403).json({ error: 'Not authorized to edit this message' });
  }

  if (content.length > 10000) {
    return res.status(400).json({ error: 'Message too long (max 10000 characters)' });
  }

  const updated = db.updateMessage(messageId, content);

  broadcastToThread(message.threadId, { type: 'message_edited', data: updated });

  res.json(updated);
});

// ============ Contacts Routes ============
app.get('/api/contacts', authenticateToken, (req, res) => {
  const contacts = db.getContactsForUser(req.user.userId);
  res.json(contacts);
});

// Search for users to add as contacts
app.get('/api/users/search', authenticateToken, (req, res) => {
  const query = sanitizeInput(req.query.q);
  
  if (!query || query.length < 2) {
    return res.json([]);
  }
  
  const users = db.searchUsers(query, req.user.userId);
  
  // Mark which ones are already contacts
  const contactIds = db.getContactsForUser(req.user.userId).map(c => c.id);
  const results = users.map(u => ({
    ...u,
    isContact: contactIds.includes(u.id),
  }));
  
  res.json(results);
});

app.post('/api/contacts', authenticateToken, (req, res) => {
  const username = sanitizeInput(req.body.username);

  const contact = db.findUserByUsername(username);
  if (!contact) {
    return res.status(404).json({ error: 'User not found' });
  }

  if (contact.id === req.user.userId) {
    return res.status(400).json({ error: 'Cannot add yourself as contact' });
  }

  const added = db.addContact(req.user.userId, contact.id);
  if (!added) {
    return res.status(409).json({ error: 'Contact already exists' });
  }

  res.status(201).json({ 
    success: true,
    contact: {
      id: contact.id,
      username: contact.username,
      name: contact.displayName,
      avatar: contact.avatar,
      status: contact.status,
      nodeName: contact.nodeName,
    }
  });
});

app.delete('/api/contacts/:id', authenticateToken, (req, res) => {
  const contactId = sanitizeInput(req.params.id);
  
  const index = db.data.contacts.findIndex(
    c => c.userId === req.user.userId && c.contactId === contactId
  );
  
  if (index === -1) {
    return res.status(404).json({ error: 'Contact not found' });
  }
  
  db.data.contacts.splice(index, 1);
  db.save();
  
  res.json({ success: true });
});

// ============ Health Check ============
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    version: '1.1.0',
    uptime: process.uptime(),
  });
});

// ============ WebSocket Setup ============
const server = createServer(app);
const wss = new WebSocketServer({ server });

const clients = new Map();

// WebSocket rate limiting
const wsConnectionAttempts = new Map();
const WS_RATE_LIMIT = 10; // connections per minute
const WS_RATE_WINDOW = 60 * 1000;

wss.on('connection', (ws, req) => {
  const ip = req.headers['x-forwarded-for']?.split(',')[0] || req.socket.remoteAddress;
  
  // Rate limit WebSocket connections
  const now = Date.now();
  const attempts = wsConnectionAttempts.get(ip) || [];
  const recentAttempts = attempts.filter(t => t > now - WS_RATE_WINDOW);
  
  if (recentAttempts.length >= WS_RATE_LIMIT) {
    ws.close(1008, 'Rate limit exceeded');
    return;
  }
  
  recentAttempts.push(now);
  wsConnectionAttempts.set(ip, recentAttempts);
  
  let userId = null;

  ws.on('message', (data) => {
    try {
      // Limit message size
      if (data.length > 10000) {
        ws.close(1009, 'Message too large');
        return;
      }
      
      const message = JSON.parse(data.toString());

      if (message.type === 'auth') {
        try {
          const decoded = jwt.verify(message.token, JWT_SECRET);
          userId = decoded.userId;

          if (!clients.has(userId)) {
            clients.set(userId, new Set());
          }
          clients.get(userId).add(ws);

          db.updateUserStatus(userId, 'online');

          ws.send(JSON.stringify({ type: 'auth_success', userId }));
        } catch (err) {
          ws.send(JSON.stringify({ type: 'auth_error', error: 'Invalid token' }));
        }
      }
    } catch (err) {
      console.error('WebSocket message error:', err);
    }
  });

  ws.on('close', () => {
    if (userId && clients.has(userId)) {
      clients.get(userId).delete(ws);
      if (clients.get(userId).size === 0) {
        clients.delete(userId);
        db.updateUserStatus(userId, 'offline');
      }
    }
  });
});

function broadcastToThread(threadId, message) {
  const participants = db.getThreadParticipants(threadId);

  for (const participant of participants) {
    if (clients.has(participant.id)) {
      for (const ws of clients.get(participant.id)) {
        if (ws.readyState === 1) {
          ws.send(JSON.stringify(message));
        }
      }
    }
  }
}

// ============ Start Server ============
server.listen(PORT, () => {
  const demoEnabled = process.env.SEED_DEMO_DATA === 'true';
  console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║   ██████╗ ██████╗ ██████╗ ████████╗███████╗██╗  ██╗        ║
║  ██╔════╝██╔═══██╗██╔══██╗╚══██╔══╝██╔════╝╚██╗██╔╝        ║
║  ██║     ██║   ██║██████╔╝   ██║   █████╗   ╚███╔╝         ║
║  ██║     ██║   ██║██╔══██╗   ██║   ██╔══╝   ██╔██╗         ║
║  ╚██████╗╚██████╔╝██║  ██║   ██║   ███████╗██╔╝ ██╗        ║
║   ╚═════╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝        ║
║                                                            ║
║  SECURE COMMUNICATIONS SYSTEM v1.1.0                       ║
║                                                            ║
╠════════════════════════════════════════════════════════════╣
║  🔒 Security Features:                                     ║
║     • Rate limiting (login: 5/15min, register: 3/hr)       ║
║     • Account lockout after 5 failed attempts              ║
║     • Input sanitization (XSS protection)                  ║
║     • Password strength requirements                       ║
║     • Security headers via Helmet                          ║
╠════════════════════════════════════════════════════════════╣
║  ✨ Features:                                              ║
║     • Public threads visible to all users                  ║
║     • User search for adding contacts                      ║
║     • Auto-join when posting to public threads             ║
╠════════════════════════════════════════════════════════════╣
║  ⚙️  Configuration:                                         ║
║     PORT=${PORT}                                               ║
║     JWT_SECRET=${JWT_SECRET === 'cortex-default-secret-CHANGE-ME' ? '⚠️  DEFAULT (change me!)' : '✅ Custom'}                         ║
║     ALLOWED_ORIGINS=${ALLOWED_ORIGINS ? '✅ Restricted' : '⚠️  All (dev mode)'}                      ║
║     SEED_DEMO_DATA=${demoEnabled ? '✅ Enabled' : '❌ Disabled'}                          ║
╠════════════════════════════════════════════════════════════╣
║  🚀 Server: http://localhost:${PORT}                           ║
║  📡 WebSocket: ws://localhost:${PORT}                          ║
╚════════════════════════════════════════════════════════════╝
`);
});
